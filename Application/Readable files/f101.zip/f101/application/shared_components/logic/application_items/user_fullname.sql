prompt --application/shared_components/logic/application_items/user_fullname
begin
--   Manifest
--     APPLICATION ITEM: USER_FULLNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_flow_item(
 p_id=>wwv_flow_imp.id(31162682502573188)
,p_name=>'USER_FULLNAME'
,p_protection_level=>'I'
,p_version_scn=>45145149211899
);
wwv_flow_imp.component_end;
end;
/
