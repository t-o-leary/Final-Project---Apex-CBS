prompt --application/shared_components/logic/application_processes/getimage
begin
--   Manifest
--     APPLICATION PROCESS: GETIMAGE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_flow_process(
 p_id=>wwv_flow_imp.id(16370013638231909)
,p_process_sequence=>1
,p_process_point=>'ON_DEMAND'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'GETIMAGE'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'',
'for c1 in (select * from CAMPUS_USERS',
'    where username = :IMAGE_ID) loop',
'',
'        sys.htp.init;',
'        sys.owa_util.mime_header( c1.MIME_TYPE, FALSE );',
'        sys.htp.p(''Content-length: '' || sys.dbms_lob.getlength( c1.PROFILE_IMAGE));',
'        sys.htp.p(''Content-Disposition: attachment; filename="'' || c1.FILE_NAME || ''"'' );',
'',
'        sys.htp.p(''Cache-Control: max-age=3600'');  -- tell the browser to cache for one hour, adjust as necessary',
'        sys.owa_util.http_header_close;',
'        sys.wpg_docload.download_file( c1.PROFILE_IMAGE);',
'',
'        apex_application.stop_apex_engine;',
'',
'    end loop;',
'end;'))
,p_process_clob_language=>'PLSQL'
,p_security_scheme=>'MUST_NOT_BE_PUBLIC_USER'
,p_version_scn=>45147636991687
);
wwv_flow_imp.component_end;
end;
/
