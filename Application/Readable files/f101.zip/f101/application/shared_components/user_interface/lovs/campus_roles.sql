prompt --application/shared_components/user_interface/lovs/campus_roles
begin
--   Manifest
--     CAMPUS_ROLES
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(34902757872370902)
,p_lov_name=>'CAMPUS_ROLES'
,p_lov_query=>'.'||wwv_flow_imp.id(34902757872370902)||'.'
,p_location=>'STATIC'
,p_version_scn=>45147149232292
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(34903127492370907)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Admin'
,p_lov_return_value=>'Admin'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(34903526647370908)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Staff'
,p_lov_return_value=>'Staff'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(34903859885370908)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Student'
,p_lov_return_value=>'Student'
);
wwv_flow_imp.component_end;
end;
/
