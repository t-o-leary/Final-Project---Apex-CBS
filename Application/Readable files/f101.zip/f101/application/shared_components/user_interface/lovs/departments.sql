prompt --application/shared_components/user_interface/lovs/departments
begin
--   Manifest
--     DEPARTMENTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(10522056826393786)
,p_lov_name=>'DEPARTMENTS'
,p_lov_query=>'.'||wwv_flow_imp.id(10522056826393786)||'.'
,p_location=>'STATIC'
,p_version_scn=>45144648621355
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10522301496393790)
,p_lov_disp_sequence=>1
,p_lov_disp_value=>'Computer Science Dept'
,p_lov_return_value=>'Computer Science Dept'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10522780257393791)
,p_lov_disp_sequence=>2
,p_lov_disp_value=>'Engineering Dept'
,p_lov_return_value=>'Engineering Dept'
);
wwv_flow_imp_shared.create_static_lov_data(
 p_id=>wwv_flow_imp.id(10523101251393791)
,p_lov_disp_sequence=>3
,p_lov_disp_value=>'Library'
,p_lov_return_value=>'Library'
);
wwv_flow_imp.component_end;
end;
/
