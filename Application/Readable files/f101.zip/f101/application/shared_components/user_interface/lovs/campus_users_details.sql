prompt --application/shared_components/user_interface/lovs/campus_users_details
begin
--   Manifest
--     CAMPUS_USERS_DETAILS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(35714254405176996)
,p_lov_name=>'CAMPUS_USERS_DETAILS'
,p_lov_query=>'select c.*, ''Y'' INTERNAL_FLAG from CAMPUS_USERS c'
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_query_table=>'CAMPUS_USERS'
,p_return_column_name=>'FULL_NAME'
,p_display_column_name=>'FULL_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'FULL_NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45147607773327
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(35740217312211040)
,p_query_column_name=>'FULL_NAME'
,p_display_sequence=>10
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(35714721468190768)
,p_query_column_name=>'USER_ID'
,p_heading=>'User Id'
,p_display_sequence=>20
,p_data_type=>'NUMBER'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(35715829815190770)
,p_query_column_name=>'EMAIL'
,p_heading=>'Email'
,p_display_sequence=>30
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(35752666924039660)
,p_query_column_name=>'INTERNAL_FLAG'
,p_heading=>'Internal Flag'
,p_display_sequence=>40
,p_data_type=>'VARCHAR2'
,p_is_visible=>'N'
,p_is_searchable=>'N'
);
wwv_flow_imp_shared.create_list_of_values_cols(
 p_id=>wwv_flow_imp.id(35716607141190770)
,p_query_column_name=>'STUDENT_STAFF_NO'
,p_heading=>'Student Staff No'
,p_display_sequence=>50
,p_data_type=>'VARCHAR2'
);
wwv_flow_imp.component_end;
end;
/
