prompt --application/shared_components/user_interface/lovs/campus_users_username
begin
--   Manifest
--     CAMPUS_USERS_USERNAME
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(12308159405852538)
,p_lov_name=>'CAMPUS_USERS_USERNAME'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'CAMPUS_USERS'
,p_return_column_name=>'USERNAME'
,p_display_column_name=>'FULL_NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'USERNAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45146297249161
);
wwv_flow_imp.component_end;
end;
/
