prompt --application/shared_components/user_interface/lovs/resources_id
begin
--   Manifest
--     RESOURCES_ID
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(31714324840002331)
,p_lov_name=>'RESOURCES_ID'
,p_source_type=>'TABLE'
,p_location=>'LOCAL'
,p_query_table=>'RESOURCES'
,p_return_column_name=>'RESOURCE_ID'
,p_display_column_name=>'NAME'
,p_group_sort_direction=>'ASC'
,p_default_sort_column_name=>'NAME'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45146303836715
);
wwv_flow_imp.component_end;
end;
/
