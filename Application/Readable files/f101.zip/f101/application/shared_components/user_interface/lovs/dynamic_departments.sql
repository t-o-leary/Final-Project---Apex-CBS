prompt --application/shared_components/user_interface/lovs/dynamic_departments
begin
--   Manifest
--     DYNAMIC_DEPARTMENTS
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list_of_values(
 p_id=>wwv_flow_imp.id(16626120164954535)
,p_lov_name=>'DYNAMIC_DEPARTMENTS'
,p_lov_query=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select column_value dept',
'from apex_string.split(''Computer Science Dept,Engineering Dept,Library'','','')',
'where column_value in(select column_value dept',
'from apex_string.split((select department from campus_users where username = :app_user),'':'')',
')',
'or ((select uppER(user_role) from campus_users where username = :app_user) =''ADMIN'')',
'union select ''Library'' from dual',
'order by dept',
''))
,p_source_type=>'SQL'
,p_location=>'LOCAL'
,p_return_column_name=>'DEPT'
,p_display_column_name=>'DEPT'
,p_group_sort_direction=>'ASC'
,p_default_sort_direction=>'ASC'
,p_version_scn=>45148243240137
);
wwv_flow_imp.component_end;
end;
/
