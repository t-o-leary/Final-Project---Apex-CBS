prompt --application/shared_components/navigation/lists/resources
begin
--   Manifest
--     LIST: Resources
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(16430283797509795)
,p_name=>'Resources'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(9897665561927782)
,p_version_scn=>45147718798896
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(16430412193509798)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Resources'
,p_list_item_link_target=>'f?p=&APP_ID.:3:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-building-o'
,p_list_text_01=>'Change Resource details and disable Resources'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
