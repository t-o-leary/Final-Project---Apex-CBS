prompt --application/shared_components/navigation/lists/quick_links
begin
--   Manifest
--     LIST: Quick Links
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(37239790744946083)
,p_name=>'Quick Links'
,p_list_status=>'PUBLIC'
,p_version_scn=>45148305461426
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37239976606946089)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Create Booking'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus-square-o'
,p_list_text_01=>'View and book resources'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37240390108946091)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Update Bookings'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-edit'
,p_list_text_01=>'Review and update upcoming bookings'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37240810477946091)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Booking History'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-clock'
,p_list_text_01=>'View previous bookings'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37241788934970345)
,p_list_item_display_sequence=>40
,p_list_item_link_text=>'Administration Dashboard '
,p_list_item_link_target=>'f?p=&APP_ID.:10000:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-gears'
,p_list_text_01=>'Contains all the Application set up and monitoring reports'
,p_security_scheme=>wwv_flow_imp.id(31122723025816318)
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
