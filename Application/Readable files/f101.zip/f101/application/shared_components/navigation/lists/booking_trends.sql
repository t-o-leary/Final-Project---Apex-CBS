prompt --application/shared_components/navigation/lists/booking_trends
begin
--   Manifest
--     LIST: Booking Trends
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(17856814193352897)
,p_name=>'Booking Trends'
,p_list_status=>'PUBLIC'
,p_version_scn=>45148346936764
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17857091498352899)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Booking Charts'
,p_list_item_link_target=>'f?p=&APP_ID.:24:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-area-chart'
,p_list_text_01=>'View booking trends'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
