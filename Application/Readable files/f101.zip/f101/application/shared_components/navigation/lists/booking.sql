prompt --application/shared_components/navigation/lists/booking
begin
--   Manifest
--     LIST: Booking
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(36289755298824594)
,p_name=>'Booking'
,p_list_status=>'PUBLIC'
,p_version_scn=>45147947792737
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(36289987597824596)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Create Booking'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus-square-o'
,p_list_text_01=>'View and book resources'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(36290374862824597)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Update Bookings'
,p_list_item_link_target=>'f?p=&APP_ID.:18:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-edit'
,p_list_text_01=>'Review and update upcoming bookings'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(36290813407824597)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Booking History'
,p_list_item_link_target=>'f?p=&APP_ID.:20:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-clock'
,p_list_text_01=>'View previous bookings'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
