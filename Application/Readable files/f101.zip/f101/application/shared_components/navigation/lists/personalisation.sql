prompt --application/shared_components/navigation/lists/personalisation
begin
--   Manifest
--     LIST: Personalisation
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(35847335501626899)
,p_name=>'Personalisation'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(29304502859077578)
,p_version_scn=>45147751953480
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(35847534021626900)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Personal Details'
,p_list_item_link_target=>'f?p=&APP_ID.:14:&SESSION.::&DEBUG.:RP,14:P14_USER_ID:&P20000_USER_ID.:'
,p_list_item_icon=>'fa-user-edit'
,p_list_text_01=>'Change your personal details and reset password'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(36024538889750923)
,p_list_item_display_sequence=>25
,p_list_item_link_text=>'Reset Password'
,p_list_item_link_target=>'f?p=&APP_ID.:15:&SESSION.::&DEBUG.:15:P15_USER_ID:&P20000_USER_ID.:'
,p_list_item_icon=>'fa-lock-password'
,p_list_text_01=>'Reset your application password'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(35848234669659045)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Customise Theme'
,p_list_item_link_target=>'#action$a-open-customize-dialog?title=Customize&amp;lang=en'
,p_list_item_icon=>'fa-laptop'
,p_list_text_01=>'Choose from Redwood Light, Vita, Vita - Dark, Vita - Red, Vita - Slate'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
