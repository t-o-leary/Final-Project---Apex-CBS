prompt --application/shared_components/navigation/lists/admin_booking
begin
--   Manifest
--     LIST: Admin Booking
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(37570288694431333)
,p_name=>'Admin Booking'
,p_list_status=>'PUBLIC'
,p_version_scn=>45148466142097
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37570492587431335)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Create Booking'
,p_list_item_link_target=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-plus-square-o'
,p_list_text_01=>'View and book resources'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37570882217431336)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Update Bookings'
,p_list_item_link_target=>'f?p=&APP_ID.:25:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-edit'
,p_list_text_01=>'Review and update upcoming bookings'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(37571281217431336)
,p_list_item_display_sequence=>30
,p_list_item_link_text=>'Booking History'
,p_list_item_link_target=>'f?p=&APP_ID.:26:&SESSION.::&DEBUG.::::'
,p_list_item_icon=>'fa-calendar-clock'
,p_list_text_01=>'View previous bookings'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
