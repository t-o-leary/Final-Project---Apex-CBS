prompt --application/shared_components/navigation/lists/push_reporting
begin
--   Manifest
--     LIST: Push Reporting
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_list(
 p_id=>wwv_flow_imp.id(17579634174114300)
,p_name=>'Push Reporting'
,p_list_status=>'PUBLIC'
,p_required_patch=>wwv_flow_imp.id(16741459958148737)
,p_version_scn=>45148274520124
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17579830956114304)
,p_list_item_display_sequence=>10
,p_list_item_link_text=>'Push Subscription Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:201120:&SESSION.::&DEBUG.:201120:::'
,p_list_item_icon=>'fa-money-check-pen'
,p_list_text_01=>'Report of all Push Notification Subcriptions'
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp_shared.create_list_item(
 p_id=>wwv_flow_imp.id(17788216029144908)
,p_list_item_display_sequence=>20
,p_list_item_link_text=>'Push Notification Reporting'
,p_list_item_link_target=>'f?p=&APP_ID.:201130:&SESSION.::&DEBUG.:201130:::'
,p_list_item_icon=>'fa-send'
,p_list_text_01=>'Report of Push notifications queued '
,p_list_item_current_type=>'TARGET_PAGE'
);
wwv_flow_imp.component_end;
end;
/
