prompt --application/shared_components/files/signpost_svg
begin
--   Manifest
--     APP STATIC FILES: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '3C73766720786D6C6E733D22687474703A2F2F7777772E77332E6F72672F323030302F737667222077696474683D22313622206865696768743D223136222066696C6C3D2263757272656E74436F6C6F722220636C6173733D2262692062692D7369676E';
wwv_flow_imp.g_varchar2_table(2) := '706F7374222076696577426F783D22302030203136203136223E0A20203C7061746820643D224D3720312E34313456344832613120312030203020302D31203176346131203120302030203020312031683576366832762D3668332E3533326131203120';
wwv_flow_imp.g_varchar2_table(3) := '3020302030202E3736382D2E33366C312E3933332D322E3332612E352E3520302030203020302D2E36344C31332E3320342E3336613120312030203020302D2E3736382D2E3336483956312E343134613120312030203020302D3220304D31322E353332';
wwv_flow_imp.g_varchar2_table(4) := '20356C312E36363620322D312E3636362032483256357A222F3E0A3C2F7376673E';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(10906701046752703)
,p_file_name=>'signpost.svg'
,p_mime_type=>'image/svg+xml'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
