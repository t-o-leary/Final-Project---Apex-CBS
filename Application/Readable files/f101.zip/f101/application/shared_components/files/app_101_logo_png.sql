prompt --application/shared_components/files/app_101_logo_png
begin
--   Manifest
--     APP STATIC FILES: 101
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp.g_varchar2_table := wwv_flow_imp.empty_varchar2_table;
wwv_flow_imp.g_varchar2_table(1) := '89504E470D0A1A0A0000000D4948445200000020000000200800000000561125280000000970485973000003E8000003E801B57B526B000000F24944415478DAEDD2CB4EC240188661EEFF1A5CE852633CB4B6A563DB8CE200A5B590204951136807E844';
wwv_flow_imp.g_varchar2_table(2) := '5C884DA75360A66E249C4BC29A7FFD2CBE37F94BF9812B9DC00E90FDC6C984EF07BC22A9F0B2BB1F4C61DD6EA16601B0CECF2E6EDE0A00D2D45BA553002A3A28EBED828A3121249AE4B95807BCD7A72C4ED2846599F8F0D3290B86E487A6B1F8071462C3';
wwv_flow_imp.g_varchar2_table(3) := 'D40C13184F650CAF2C03CA720D98A0BA00F3EE2744B6ABA2A6551F751CCF711BCFAFB6AB54971B84E0F6A0F18E6BAD2119B5FD7E84F19C7F8D5747D2474DB97B9014DDBB965F24700F928D0AFAED22C70B7B83C80F83108741B69539636C767ADAE3C11F';
wwv_flow_imp.g_varchar2_table(4) := '53A6DDE94FEFBC4D0000000049454E44AE426082';
wwv_flow_imp_shared.create_app_static_file(
 p_id=>wwv_flow_imp.id(32896395967868362)
,p_file_name=>'app-101-logo.png'
,p_mime_type=>'image/png'
,p_file_charset=>'utf-8'
,p_file_content => wwv_flow_imp.varchar2_to_blob(wwv_flow_imp.g_varchar2_table)
);
wwv_flow_imp.component_end;
end;
/
