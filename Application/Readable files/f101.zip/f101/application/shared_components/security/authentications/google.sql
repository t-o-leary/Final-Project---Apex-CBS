prompt --application/shared_components/security/authentications/google
begin
--   Manifest
--     AUTHENTICATION: GOOGLE
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_shared.create_authentication(
 p_id=>wwv_flow_imp.id(31151715736234596)
,p_name=>'GOOGLE'
,p_scheme_type=>'NATIVE_SOCIAL'
,p_attribute_01=>wwv_flow_imp.id(7712964544849891)
,p_attribute_02=>'GOOGLE'
,p_attribute_07=>'profile'
,p_attribute_09=>'#sub# (#APEX_AUTH_NAME#)'
,p_attribute_10=>'name,picture'
,p_attribute_11=>'Y'
,p_attribute_13=>'N'
,p_attribute_14=>'USER_FULLNAME,G_PICTURE'
,p_invalid_session_type=>'LOGIN'
,p_logout_url=>'https://accounts.google.com/logout'
,p_use_secure_cookie_yn=>'N'
,p_ras_mode=>0
,p_switch_in_session_yn=>'Y'
,p_version_scn=>45147637423544
);
wwv_flow_imp.component_end;
end;
/
