prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(16577246995538111)
,p_plug_name=>'AI Chat bot'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- ==============================================================================================================',
unistr('  Author       : Tim O\2019Leary'),
'  Student ID   : 23287021',
'  Version      : 1.0',
'  Program      : Higher Diploma in Science in Computing',
'  Module       : Project (HDSDEV_JAN25)',
'  Lecturer     : Lisa Murphy',
'',
'  Description  : Embeds the n8n chatbot widget globally via Page 0 in Oracle APEX.',
'',
'  Source       : Starter code adapted from @n8n/chat',
'                 https://www.npmjs.com/package/@n8n/chat',
'',
'  Notes        :',
'    - The widget loads globally across all pages via Page 0.',
'    - CSS variables can be customized for theme integration.',
'============================================================================================================== -->',
'',
'',
'',
'',
'',
'<!-- Load the n8n chat widget stylesheet -->',
'<link href="https://cdn.jsdelivr.net/npm/@n8n/chat/dist/style.css" rel="stylesheet" />',
'',
'<!-- Container element where the chat widget will be -->',
'<div id="n8n-chat"></div>',
'',
'<!-- Initialize the chat widget -->',
'<script type="module">',
'  // Import the createChat function from n8n',
'  import { createChat } from "https://cdn.jsdelivr.net/npm/@n8n/chat/dist/chat.bundle.es.js";',
'',
'  // Call createChat ',
'  createChat({',
'    webhookUrl: "https://cba25.app.n8n.cloud/webhook/76d4105c-36cc-4d6e-92d2-82df75665d5e/chat",',
'',
'    //  CSS selector for the container element where the chat widget will render',
'    target: "#n8n-chat",',
'',
'    // Mode ',
'    // "window" = floating toggle button + chat window',
'    mode: "window",',
'',
'    // Show a welcome screen before the chat starts',
'    showWelcomeScreen: true,',
'',
'    // Initial messages shown when the chat opens',
'    initialMessages: ["Hi &USER_FULLNAME.", "Ask me anything about this app!"],',
'',
'    // Pass metadata to personalize the chat',
'     metadata: { userId: "&APP_USER.", email: "&APP_EMAIL." }',
'  });',
'</script>',
'',
'<!-- Global CSS overrides for styling -->',
'<style>',
':root {',
'  /* Primary colour for buttons and highlights */',
'  --chat--color--primary: #006699;',
'',
'',
'  /* Dimensions of the floating chat window */',
'  --chat--window--width: 360px;',
'  --chat--window--height: 500px;',
'',
'',
'   /* Default (light mode) input text color */',
'  --chat--input--text-color: #222222;        /* dark grey text on light background */',
'  --chat--input--placeholder-color: #666666; /* softer grey for placeholder text */',
'}',
'',
'/* Dark mode override */',
'@media (prefers-color-scheme: dark) {',
'  :root {',
'    --chat--input--text-color: #f0f0f0;        /* light text for visibility */',
'    --chat--input--placeholder-color: #aaaaaa; /* lighter grey placeholder */',
'  }',
'',
'}',
'</style>',
''))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'instr('':'' ||''4:5:9:11:13:14:15:17:21:9999:10010:10020:10030:10031:10032:10033:10034:10035:10036:10040:10041:10042:10043:10044:10050:10051:20110:201130''|| '':'',',
'      '':'' || :APP_PAGE_ID|| '':'')=0'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(10118821145962146)
,p_name=>'Set full name'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(10118901932962147)
,p_event_id=>wwv_flow_imp.id(10118821145962146)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'select full_name ',
'into :USER_FULLNAME ',
'from campus_users where upper(username) = upper(apex_custom_auth.get_username);',
'',
'',
' EXCEPTION',
' WHEN OTHERS THEN',
' :USER_FULLNAME := apex_custom_auth.get_username;',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
