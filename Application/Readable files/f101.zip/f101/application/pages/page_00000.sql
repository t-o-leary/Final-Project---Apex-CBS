prompt --application/pages/page_00000
begin
--   Manifest
--     PAGE: 00000
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>0
,p_name=>'Global Page'
,p_step_title=>'Global Page'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_protection_level=>'D'
,p_page_component_map=>'14'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(35984084292687907)
,p_plug_name=>'AI Chat bot'
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_05'
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<!-- Load the n8n chat widget stylesheet -->',
'<link href="https://cdn.jsdelivr.net/npm/@n8n/chat/dist/style.css" rel="stylesheet" />',
'',
'<!-- Container element where the chat widget will be -->',
'<div id="n8n-chat"></div>',
'',
'<!-- Initialize the chat widget -->',
'<script type="module">',
'  import { createChat } from "https://cdn.jsdelivr.net/npm/@n8n/chat/dist/chat.bundle.es.js";',
'',
'  createChat({',
'    webhookUrl: "https://timoleary83.app.n8n.cloud/webhook/76d4105c-36cc-4d6e-92d2-82df75665d5e/chat",',
'    target: "#n8n-chat",',
'    mode: "window",',
'    showWelcomeScreen: true,',
'    initialMessages: ["Hi &USER_FULLNAME.", "Ask me anything about this app!"],',
'    metadata: { userId: "&APP_USER.", email: "&APP_EMAIL." }',
'  });',
'</script>',
'',
'<!-- Theme variables and mobile-only overrides including landscape handling -->',
'<style>',
':root{',
'  --chat--color--primary: #006699;',
'  --chat--window--width: 360px;',
'  --chat--window--height: 500px;',
'  --chat--input--text-color: #222222;',
'  --chat--input--placeholder-color: #666666;',
'',
'  /* Mobile offsets: portrait and landscape (adjust values to match your UI) */',
'  --chat--mobile-bottom-offset-portrait: calc(env(safe-area-inset-bottom, 0px) + 72px);',
'  --chat--mobile-bottom-offset-landscape: calc(env(safe-area-inset-bottom, 0px) + 40px);',
'}',
'',
'/* Dark mode variables */',
'@media (prefers-color-scheme: dark){',
'  :root{',
'    --chat--input--text-color: #f0f0f0;',
'    --chat--input--placeholder-color: #aaaaaa;',
'  }',
'}',
'',
'/* ===== Mobile portrait overrides ===== */',
'@media (max-width: 600px) and (orientation: portrait) {',
'  :root { --chat--mobile-bottom-offset: var(--chat--mobile-bottom-offset-portrait); }',
'',
'  #n8n-chat .chat-window-wrapper,',
'  #n8n-chat .n8n-chat,',
'  .chat-window-wrapper,',
'  .n8n-chat {',
'    position: fixed !important;',
'    right: 12px !important;',
'    left: 12px !important;',
'    bottom: var(--chat--mobile-bottom-offset) !important;',
'    z-index: 99999 !important;',
'    width: calc(100% - 24px) !important;',
'    max-width: none !important;',
'    height: auto !important;',
'    max-height: calc(100% - (env(safe-area-inset-top, 0px) + env(safe-area-inset-bottom, 0px) + 120px)) !important;',
'    border-radius: 12px !important;',
'    box-sizing: border-box !important;',
'    transition: transform 200ms ease, bottom 200ms ease !important;',
'  }',
'',
'  #n8n-chat input,',
'  #n8n-chat textarea,',
'  .chat-window-wrapper input,',
'  .chat-window-wrapper textarea,',
'  .n8n-chat input,',
'  .n8n-chat textarea {',
'    color: #0b0b0b !important;',
'    caret-color: #0b0b0b !important;',
'  }',
'',
'  #n8n-chat input::placeholder,',
'  #n8n-chat textarea::placeholder,',
'  .chat-window-wrapper input::placeholder,',
'  .chat-window-wrapper textarea::placeholder,',
'  .n8n-chat input::placeholder,',
'  .n8n-chat textarea::placeholder {',
'    color: #666666 !important;',
'    opacity: 1 !important;',
'  }',
'}',
'',
'/* ===== Mobile landscape overrides ===== */',
'@media (max-width: 900px) and (orientation: landscape) {',
'  /* wider max-width to catch tablets turned on side; adjust breakpoint as needed */',
'  :root { --chat--mobile-bottom-offset: var(--chat--mobile-bottom-offset-landscape); }',
'',
'  #n8n-chat .chat-window-wrapper,',
'  #n8n-chat .n8n-chat,',
'  .chat-window-wrapper,',
'  .n8n-chat {',
'    position: fixed !important;',
'    right: 12px !important;',
'    left: 12px !important;',
'    bottom: var(--chat--mobile-bottom-offset) !important;',
'    z-index: 99999 !important;',
'    width: 420px !important; /* slightly wider in landscape */',
'    max-width: calc(100% - 24px) !important;',
'    height: auto !important;',
'    max-height: calc(100% - (env(safe-area-inset-top, 0px) + env(safe-area-inset-bottom, 0px) + 80px)) !important;',
'    border-radius: 10px !important;',
'    box-sizing: border-box !important;',
'    transition: transform 200ms ease, bottom 200ms ease !important;',
'  }',
'',
'  /* Ensure toggle button respects landscape offset */',
'  #n8n-chat .chat-toggle,',
'  .chat-toggle,',
'  #n8n-chat .chat-button,',
'  .chat-button {',
'    position: fixed !important;',
'    right: 12px !important;',
'    bottom: var(--chat--mobile-bottom-offset) !important;',
'    z-index: 99998 !important;',
'  }',
'',
'  /* Darker input text in landscape as well */',
'  #n8n-chat input,',
'  #n8n-chat textarea,',
'  .chat-window-wrapper input,',
'  .chat-window-wrapper textarea,',
'  .n8n-chat input,',
'  .n8n-chat textarea {',
'    color: #0b0b0b !important;',
'    caret-color: #0b0b0b !important;',
'  }',
'',
'  #n8n-chat input::placeholder,',
'  #n8n-chat textarea::placeholder,',
'  .chat-window-wrapper input::placeholder,',
'  .chat-window-wrapper textarea::placeholder,',
'  .n8n-chat input::placeholder,',
'  .n8n-chat textarea::placeholder {',
'    color: #666666 !important;',
'    opacity: 1 !important;',
'  }',
'}',
'',
'/* Desktop and normal screens remain untouched and use the library defaults */',
'</style>',
'',
'<!-- Runtime helper to ensure mobile portrait and landscape overrides apply after widget insertion -->',
'<script>',
'(function () {',
'  const portraitMax = 600;   // mobile portrait breakpoint',
'  const landscapeMax = 900;  // mobile landscape breakpoint (adjust if needed)',
'',
'  // Minimal CSS to inject so rules are last in head when on mobile or landscape',
'  function injectMobileCss() {',
'    if (document.head.querySelector(''style[data-n8n-mobile]'')) return;',
'    const css = `',
'      /* keep minimal; orientation-specific rules are already in the main stylesheet */',
'      #n8n-chat .chat-window-wrapper,',
'      #n8n-chat .n8n-chat,',
'      .chat-window-wrapper,',
'      .n8n-chat { z-index: 99999 !important; }',
'    `;',
'    const s = document.createElement(''style'');',
'    s.setAttribute(''data-n8n-mobile'', ''true'');',
'    s.appendChild(document.createTextNode(css));',
'    document.head.appendChild(s);',
'  }',
'',
'  // Apply inline styles to the widget wrapper when it appears (best-effort)',
'  function applyInlineToWidget() {',
'    const w = window.innerWidth;',
'    const isPortrait = (window.matchMedia && window.matchMedia(''(orientation: portrait)'').matches);',
'    const wrapper = document.querySelector(''#n8n-chat .chat-window-wrapper'') || document.querySelector(''.chat-window-wrapper'') || document.querySelector(''.n8n-chat'');',
'    if (!wrapper) return false;',
'',
'    // Only apply inline overrides for mobile portrait or landscape',
'    if ((isPortrait && w <= portraitMax) || (!isPortrait && w <= landscapeMax)) {',
'      const bottom = getComputedStyle(document.documentElement).getPropertyValue(''--chat--mobile-bottom-offset'') || ''calc(env(safe-area-inset-bottom, 0px) + 72px)'';',
'      wrapper.style.position = ''fixed'';',
'      wrapper.style.right = ''12px'';',
'      wrapper.style.left = ''12px'';',
'      wrapper.style.bottom = bottom.trim();',
'      wrapper.style.zIndex = ''99999'';',
'      // width adjustments for landscape vs portrait',
'      if (!isPortrait && w <= landscapeMax) {',
'        wrapper.style.width = ''420px'';',
'        wrapper.style.maxWidth = ''calc(100% - 24px)'';',
'      } else {',
'        wrapper.style.width = ''calc(100% - 24px)'';',
'        wrapper.style.maxWidth = ''none'';',
'      }',
'      return true;',
'    }',
'',
'    // If not mobile, remove any inline overrides we previously set',
'    wrapper.style.position = '''';',
'    wrapper.style.right = '''';',
'    wrapper.style.left = '''';',
'    wrapper.style.bottom = '''';',
'    wrapper.style.zIndex = '''';',
'    wrapper.style.width = '''';',
'    wrapper.style.maxWidth = '''';',
'    return true;',
'  }',
'',
'  function init() {',
'    injectMobileCss();',
'    applyInlineToWidget();',
'',
'    // Observe DOM for widget insertion and apply overrides if on mobile',
'    const observer = new MutationObserver((mutations, obs) => {',
'      if (applyInlineToWidget()) obs.disconnect();',
'    });',
'    observer.observe(document.body, { childList: true, subtree: true });',
'  }',
'',
'  // Re-run on load, resize and orientation change',
'  window.addEventListener(''load'', init);',
'  window.addEventListener(''resize'', () => {',
'    // remove injected mobile style if viewport becomes larger',
'    const mobileStyle = document.head.querySelector(''style[data-n8n-mobile]'');',
'    if (window.innerWidth > landscapeMax && mobileStyle) mobileStyle.remove();',
'    init();',
'  });',
'  window.addEventListener(''orientationchange'', () => {',
'    // small delay to allow orientation metrics to settle',
'    setTimeout(init, 150);',
'  });',
'})();',
'</script>',
''))
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
'instr('':'' ||''4:5:9:11:13:14:15:17:21:9999:10010:10020:10030:10031:10032:10033:10034:10035:10036:10040:10041:10042:10043:10044:10050:10051:20110:201130''|| '':'',',
'      '':'' || :APP_PAGE_ID|| '':'')=0'))
,p_plug_display_when_cond2=>'PLSQL'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(29525658443111942)
,p_name=>'Set full name'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(29525739230111943)
,p_event_id=>wwv_flow_imp.id(29525658443111942)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_EXECUTE_PLSQL_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'select full_name ',
'into :USER_FULLNAME ',
'from campus_users where upper(username) = upper(apex_custom_auth.get_username);',
'',
'',
' EXCEPTION',
' WHEN OTHERS THEN',
' :USER_FULLNAME := apex_custom_auth.get_username;',
'end;'))
,p_attribute_05=>'PLSQL'
,p_wait_for_result=>'Y'
);
wwv_flow_imp.component_end;
end;
/
