prompt --application/pages/page_00001
begin
--   Manifest
--     PAGE: 00001
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>1
,p_name=>'Campus'
,p_alias=>'CAMPUS'
,p_step_title=>'Campus Booking System'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(34914726140470273)
,p_protection_level=>'C'
,p_page_component_map=>'13'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29316834939077625)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(29300393125077500)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521311222111898)
,p_plug_name=>'Options'
,p_region_css_classes=>'rounded rounded-lg'
,p_region_template_options=>'#DEFAULT#:js-showMaximizeButton:js-cycle5s:t-Region--hiddenOverflow'
,p_plug_template=>2867287278109674555
,p_plug_display_sequence=>20
,p_plug_new_grid_row=>false
,p_location=>null
,p_landmark_type=>'exclude_landmark'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521354171111899)
,p_plug_name=>'Lecture Hall'
,p_title=>'Lecture Hall'
,p_parent_plug_id=>wwv_flow_imp.id(29521311222111898)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_plug_source=>'Lecture Hall'
,p_region_image=>'#APP_FILES#lecture_hall.avif'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521517897111900)
,p_plug_name=>'Desk'
,p_parent_plug_id=>wwv_flow_imp.id(29521311222111898)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>50
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#desk.avif'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521578572111901)
,p_plug_name=>'Equiptment'
,p_parent_plug_id=>wwv_flow_imp.id(29521311222111898)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>60
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#equiptment.jpg'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521663900111902)
,p_plug_name=>'Class Rooms'
,p_parent_plug_id=>wwv_flow_imp.id(29521311222111898)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#class_room.avif'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521805695111903)
,p_plug_name=>'Meeting Rooms'
,p_parent_plug_id=>wwv_flow_imp.id(29521311222111898)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#meeting_room.avif'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(29521897932111904)
,p_plug_name=>'Lab'
,p_parent_plug_id=>wwv_flow_imp.id(29521311222111898)
,p_region_template_options=>'#DEFAULT#:t-ImageRegion--stretch:t-ImageRegion--auto:t-ImageRegion--cover:t-ImageRegion--square:t-ImageRegion--noFilter'
,p_plug_template=>1675400448429897403
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_location=>null
,p_region_image=>'#APP_FILES#lab.avif'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64241299880874172)
,p_plug_name=>'Column 1'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>3371237801798025892
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_query_num_rows=>15
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML',
  'show_line_breaks', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(64241713543874172)
,p_plug_name=>'Quick Links'
,p_parent_plug_id=>wwv_flow_imp.id(64241299880874172)
,p_region_template_options=>'#DEFAULT#:t-Region--noPadding:t-Region--scrollBody'
,p_component_template_options=>'#DEFAULT#:u-colors'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_list_id=>wwv_flow_imp.id(37239790744946083)
,p_plug_source_type=>'NATIVE_LIST'
,p_list_template_id=>2067994871570597190
,p_plug_query_num_rows=>15
,p_required_patch=>wwv_flow_imp.id(29304906219077578)
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(33921561819226797)
,p_process_sequence=>10
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'New'
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'begin',
'    apex_mail.send (',
'        p_to                 => ''TOLEARY83@GMAIL.COM'',',
'        p_template_static_id => ''ACCESS_GRANTED'',',
'        p_placeholders       => ''{'' ||',
'        ''    "NAME":''                || apex_json.stringify( ''some_value'' ) ||',
'        ''   ,"ROLE":''                || apex_json.stringify( ''some_value'' ) ||',
'        ''   ,"URL":''                 || apex_json.stringify( ''some_value'' ) ||',
'        ''   ,"MY_APPLICATION_LINK":'' || apex_json.stringify( apex_mail.get_instance_url || apex_page.get_url( 1)) ||',
'        ''}'' );',
'end;',
'',
'',
'Apex_mail.push_queue;'))
,p_process_clob_language=>'PLSQL'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_process_success_message=>'sent'
,p_required_patch=>wwv_flow_imp.id(29299792634077496)
,p_internal_uid=>14514724522077001
);
wwv_flow_imp.component_end;
end;
/
