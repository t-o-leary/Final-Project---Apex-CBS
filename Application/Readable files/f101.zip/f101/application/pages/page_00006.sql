prompt --application/pages/page_00006
begin
--   Manifest
--     PAGE: 00006
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>6
,p_name=>'Calendar'
,p_alias=>'CALENDAR'
,p_step_title=>'Calendar'
,p_autocomplete_on_off=>'OFF'
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(15507888843320477)
,p_page_component_map=>'08'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(17554709281637748)
,p_plug_name=>'Breadcrumb'
,p_title=>'Calendar'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(9893555827927704)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(25396271065232501)
,p_plug_name=>'Calendar'
,p_region_template_options=>'#DEFAULT#:t-ContentBlock--h3:t-ContentBlock--hideHeader js-addHiddenHeadingRoleDesc'
,p_plug_template=>2322115667525957943
,p_plug_display_sequence=>70
,p_query_type=>'TABLE'
,p_query_table=>'BOOKINGS_V'
,p_query_where=>'RESOURCE_code = :P6_RESOURCE_BUTID'
,p_include_rowid_column=>true
,p_lazy_loading=>true
,p_plug_source_type=>'NATIVE_CSS_CALENDAR'
,p_plugin_init_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'function ( pOptions) {',
'    pOptions.locale = ''en-IE'';                                                     // set location',
'  //  pOptions.titleFormat      = "[Schedule]";                                // custom title',
'    pOptions.slotMinTime      = "07:00:00";                                             // hide slots before minTime',
'    pOptions.slotMaxTime      = "18:00:00";                                             // hide slots after maxTime',
'    pOptions.dayHeaderFormat  = { weekday: ''short'', month: ''numeric'', day: ''numeric'' }; // week view column headings',
'    pOptions.slotDuration     = "00:15:00";                                             // custom slot duration',
'    pOptions.weekNumbers      = true;',
'    pOptions.displayEventTime = true;                                     // show event time ...',
'    pOptions.displayEventEnd  = false;                                    // ... but not the end time',
'    pOptions.windowResize     = null;                                                   // show week numbers',
'    pOptions.weekText         = "CW";                                           // heading for week numbers',
'    pOptions.weekNumberCalculation  = "ISO";                                                    // use "ISO" week numbers',
'  ',
'',
'                                       ',
'    return pOptions;',
'}'))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'calendar_views_and_navigation', 'week:day:list:navigation',
  'css_class', 'CSS_CLASS',
  'display_column', 'NAME',
  'drag_and_drop', 'N',
  'end_date_column', 'END_TS',
  'event_sorting', 'AUTOMATIC',
  'first_hour', '8',
  'maximum_events_day', '50',
  'multiple_line_event', 'Y',
  'primary_key_column', 'ID',
  'show_time', 'Y',
  'show_tooltip', 'Y',
  'show_weekend', 'Y',
  'start_date_column', 'START_TS',
  'supplemental_information', 'Booking between &START_TS. and &END_TS.',
  'time_format', '24')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(14142256240573701)
,p_button_sequence=>20
,p_button_name=>'Back'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--large:t-Button--primary:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Back'
,p_button_redirect_url=>'f?p=&APP_ID.:12:&SESSION.::&DEBUG.:6:P12_DEPARTMENT,P12_RESOURCE_TYPE,P12_RESOURCE_BUTID:&P6_DEPARTMENT.,&P6_RESOURCE_TYPE.,&P6_RESOURCE_BUTID.'
,p_icon_css_classes=>'fa-backward'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13099051567499383)
,p_name=>'P6_DEPARTMENT'
,p_item_sequence=>30
,p_prompt=>'Department'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'DEPARTMENTS'
,p_lov=>'.'||wwv_flow_imp.id(10522056826393786)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13099377918501983)
,p_name=>'P6_RESOURCE_ID'
,p_item_sequence=>50
,p_prompt=>'Resource Name'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'RESOURCES_ID'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13099677286505762)
,p_name=>'P6_DATETIME'
,p_item_sequence=>80
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14142312715573702)
,p_name=>'P6_RESOURCE_TYPE'
,p_item_sequence=>40
,p_prompt=>'Resource'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'RESOURCES_TYPES'
,p_lov=>'.'||wwv_flow_imp.id(10523474662403468)||'.'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_begin_on_new_line=>'N'
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_lov_display_extra=>'YES'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(14142635712573705)
,p_name=>'P6_RESOURCE_BUTID'
,p_item_sequence=>60
,p_display_as=>'NATIVE_HIDDEN'
,p_encrypt_session_state_yn=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'N')).to_clob
);
wwv_flow_imp.component_end;
end;
/
