prompt --application/pages/page_201130
begin
--   Manifest
--     PAGE: 201130
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>201130
,p_name=>'Push Reporting'
,p_alias=>'PUSH-REPORTING'
,p_page_mode=>'MODAL'
,p_step_title=>'Push Reporting'
,p_warn_on_unsaved_changes=>'N'
,p_autocomplete_on_off=>'OFF'
,p_step_template=>2100407606326202693
,p_page_template_options=>'#DEFAULT#:ui-dialog--stretch:t-Dialog--noPadding'
,p_required_role=>wwv_flow_imp.id(31122723025816318)
,p_required_patch=>wwv_flow_imp.id(36148297255298533)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_help_text=>'<p>This report shows all email queued to be sent and those already sent.</p>'
,p_page_component_map=>'18'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(71283066375514703)
,p_plug_name=>'Push Reporting'
,p_region_template_options=>'#DEFAULT#:t-IRR-region--noBorders'
,p_plug_template=>2100526641005906379
,p_plug_display_sequence=>10
,p_query_type=>'SQL'
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'select * from APEX_PUSH_NOTIFICATIONS_QUEUE',
'order by 1;'))
,p_plug_source_type=>'NATIVE_IR'
,p_prn_page_header=>'Email Reporting'
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_worksheet(
 p_id=>wwv_flow_imp.id(71283584470514706)
,p_name=>'Email Reporting'
,p_max_row_count_message=>'The maximum row count for this report is #MAX_ROW_COUNT# rows.  Please apply a filter to reduce the number of records in your query.'
,p_no_data_found_message=>'No data found.'
,p_pagination_type=>'ROWS_X_TO_Y'
,p_pagination_display_pos=>'BOTTOM_RIGHT'
,p_report_list_mode=>'TABS'
,p_lazy_loading=>false
,p_show_detail_link=>'N'
,p_show_notify=>'Y'
,p_download_formats=>'CSV:HTML:XLSX:PDF'
,p_enable_mail_download=>'Y'
,p_owner=>'TOLEARY'
,p_internal_uid=>51876747173364910
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71284615283514716)
,p_db_column_name=>'ID'
,p_display_order=>2
,p_column_identifier=>'B'
,p_column_label=>'ID'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71288234607514718)
,p_db_column_name=>'LAST_UPDATED_BY'
,p_display_order=>11
,p_column_identifier=>'K'
,p_column_label=>'Updated By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(71288649121514719)
,p_db_column_name=>'LAST_UPDATED_ON'
,p_display_order=>12
,p_column_identifier=>'L'
,p_column_label=>'Updated'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36958995034787518)
,p_db_column_name=>'FLOW_ID'
,p_display_order=>22
,p_column_identifier=>'V'
,p_column_label=>'Flow Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959119293787519)
,p_db_column_name=>'PUSH_SUBSCRIPTION_ID'
,p_display_order=>32
,p_column_identifier=>'W'
,p_column_label=>'Push Subscription Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959143304787520)
,p_db_column_name=>'TITLE'
,p_display_order=>42
,p_column_identifier=>'X'
,p_column_label=>'Title'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'Y'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959279836787521)
,p_db_column_name=>'BODY'
,p_display_order=>52
,p_column_identifier=>'Y'
,p_column_label=>'Body'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959355384787522)
,p_db_column_name=>'ICON_URL'
,p_display_order=>62
,p_column_identifier=>'Z'
,p_column_label=>'Icon Url'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959501371787523)
,p_db_column_name=>'TARGET_URL'
,p_display_order=>72
,p_column_identifier=>'AA'
,p_column_label=>'Target Url'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959597724787524)
,p_db_column_name=>'SEND_ATTEMPTS_COUNT'
,p_display_order=>82
,p_column_identifier=>'AB'
,p_column_label=>'Send Attempts Count'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959668076787525)
,p_db_column_name=>'ERROR_MESSAGE'
,p_display_order=>92
,p_column_identifier=>'AC'
,p_column_label=>'Error Message'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959768554787526)
,p_db_column_name=>'CREATED_ON'
,p_display_order=>102
,p_column_identifier=>'AD'
,p_column_label=>'Created On'
,p_column_type=>'DATE'
,p_heading_alignment=>'LEFT'
,p_tz_dependent=>'N'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36959869464787527)
,p_db_column_name=>'CREATED_BY'
,p_display_order=>112
,p_column_identifier=>'AE'
,p_column_label=>'Created By'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36960033223787528)
,p_db_column_name=>'WORKSPACE_ID'
,p_display_order=>122
,p_column_identifier=>'AF'
,p_column_label=>'Workspace Id'
,p_column_type=>'NUMBER'
,p_heading_alignment=>'RIGHT'
,p_column_alignment=>'RIGHT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_column(
 p_id=>wwv_flow_imp.id(36960075802787529)
,p_db_column_name=>'WORKSPACE_NAME'
,p_display_order=>132
,p_column_identifier=>'AG'
,p_column_label=>'Workspace Name'
,p_column_type=>'STRING'
,p_heading_alignment=>'LEFT'
,p_use_as_row_header=>'N'
);
wwv_flow_imp_page.create_worksheet_rpt(
 p_id=>wwv_flow_imp.id(71299236676514729)
,p_application_user=>'APXWS_DEFAULT'
,p_report_seq=>10
,p_report_alias=>'167580'
,p_status=>'PUBLIC'
,p_is_default=>'Y'
,p_report_columns=>'ICON_URL:ID:FLOW_ID:BODY:CREATED_BY:CREATED_ON:ERROR_MESSAGE:PUSH_SUBSCRIPTION_ID:SEND_ATTEMPTS_COUNT:TARGET_URL:TITLE:LAST_UPDATED_ON:LAST_UPDATED_BY:WORKSPACE_ID:WORKSPACE_NAME:'
,p_sort_column_1=>'MAIL_MESSAGE_CREATED'
,p_sort_direction_1=>'DESC'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(36985651277259700)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(71283066375514703)
,p_button_name=>'RESET_REPORT'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'t-Button--iconLeft'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Reset'
,p_button_position=>'RIGHT_OF_IR_SEARCH_BAR'
,p_button_redirect_url=>'f?p=&APP_ID.:&APP_PAGE_ID.:&APP_SESSION.::&DEBUG.:&APP_PAGE_ID.,RR::'
,p_icon_css_classes=>'fa-undo-alt'
);
wwv_flow_imp.component_end;
end;
/
