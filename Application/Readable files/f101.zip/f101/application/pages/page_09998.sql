prompt --application/pages/page_09998
begin
--   Manifest
--     PAGE: 09998
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>101
,p_default_id_offset=>0
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>9998
,p_name=>'User Verification'
,p_alias=>'USER-VERIFICATION'
,p_step_title=>'User Verification'
,p_warn_on_unsaved_changes=>'N'
,p_first_item=>'AUTO_FIRST_ITEM'
,p_autocomplete_on_off=>'OFF'
,p_inline_css=>wwv_flow_string.join(wwv_flow_t_varchar2(
'.app-Form-fieldContainer--verificationCode input.apex-item-text { height: 72px; font-size: 40px; line-height: 72px; }',
'.apex-item-text.apex-page-item-error:focus { border-color: #ff6448 !important; }',
'#P1_VERIFICATION_CODE_CONTAINER .t-Form-error { color: #ff6448 !important; font-weight: bold; }',
'.t-Alert--wizard .t-Alert-title { font-weight: 700; font-size: 32px; }',
'.t-Alert--wizard .t-Alert-body { text-align: center; margin-left: auto; margin-right: auto; }'))
,p_step_template=>2101157952850466385
,p_page_template_options=>'#DEFAULT#'
,p_page_is_public_y_n=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(6394654453477870940)
,p_plug_name=>'User Verification'
,p_icon_css_classes=>'app-icon'
,p_region_template_options=>'#DEFAULT#:js-headingLevel-1'
,p_plug_template=>2674157997338192145
,p_plug_display_sequence=>10
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13943137044481738039)
,p_plug_name=>'token maxed'
,p_parent_plug_id=>wwv_flow_imp.id(6394654453477870940)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--warning:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>20
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'<p>No more access attempts left, request a new token.</p>'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''Y'''))
,p_plug_display_when_cond2=>'SQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13943137590138738044)
,p_plug_name=>'account locked'
,p_parent_plug_id=>wwv_flow_imp.id(6394654453477870940)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#:t-Alert--wizard:t-Alert--customIcons:t-Alert--danger:t-Alert--removeHeading js-removeLandmark'
,p_plug_template=>2040683448887306517
,p_plug_display_sequence=>30
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_plug_source=>'Maximum verification attempts exceeded.   Account will reset in &P9998_RESET_VERIFY_AFTER_X_HOURS. hours.'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>':P9998_IS_ACCOUNT_LOCKED_YN = ''Y'''
,p_plug_display_when_cond2=>'SQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13943137680348738045)
,p_plug_name=>'for token'
,p_parent_plug_id=>wwv_flow_imp.id(6394654453477870940)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>10
,p_plug_display_point=>'SUB_REGIONS'
,p_translate_title=>'N'
,p_plug_display_condition_type=>'EXPRESSION'
,p_plug_display_when_condition=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''N'''))
,p_plug_display_when_cond2=>'SQL'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(13943138203101738050)
,p_plug_name=>'for cancel'
,p_parent_plug_id=>wwv_flow_imp.id(6394654453477870940)
,p_icon_css_classes=>'fa-exclamation-circle'
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>40
,p_plug_display_point=>'SUB_REGIONS'
,p_plug_item_display_point=>'BELOW'
,p_translate_title=>'N'
,p_ai_enabled=>false
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15518201158411335)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(13943138203101738050)
,p_button_name=>'cancel'
,p_button_action=>'REDIRECT_PAGE'
,p_button_template_options=>'#DEFAULT#:t-Button--link:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_alignment=>'RIGHT'
,p_button_redirect_url=>'f?p=&APP_ID.:1:&SESSION.::&DEBUG.:9998::'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(15516260931411333)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(13943137680348738045)
,p_button_name=>'VERIFY'
,p_button_action=>'SUBMIT'
,p_button_template_options=>'#DEFAULT#:t-Button--stretch'
,p_button_template_id=>4072362960822175091
,p_button_is_hot=>'Y'
,p_button_image_alt=>'Verify'
,p_button_alignment=>'RIGHT'
,p_grid_new_row=>'Y'
);
wwv_flow_imp_page.create_page_branch(
 p_id=>wwv_flow_imp.id(15525041047411352)
,p_branch_name=>'go to login if P9998_USERNAME is null'
,p_branch_action=>'f?p=&APP_ID.:9999:&SESSION.::&DEBUG.:9998,9999::'
,p_branch_point=>'BEFORE_HEADER'
,p_branch_type=>'REDIRECT_URL'
,p_branch_sequence=>10
,p_branch_condition_type=>'ITEM_IS_NULL'
,p_branch_condition=>'P9998_USERNAME'
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6394657013652870965)
,p_name=>'P9998_USERNAME'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13943137680348738045)
,p_prompt=>'Username'
,p_display_as=>'NATIVE_DISPLAY_ONLY'
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'based_on', 'VALUE',
  'format', 'PLAIN',
  'send_on_page_submit', 'Y',
  'show_line_breaks', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(6394660826913871003)
,p_name=>'P9998_CODE'
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(13943137680348738045)
,p_prompt=>'Verification Code'
,p_placeholder=>'000000'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>6
,p_cMaxlength=>6
,p_tag_css_classes=>'w260 margin-auto u-tC'
,p_tag_attributes=>'inputmode="numeric" pattern="[0-9]*" autocomplete="one-time-code"'
,p_display_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''N'''))
,p_display_when2=>'SQL'
,p_display_when_type=>'EXPRESSION'
,p_field_template=>2040785906935475274
,p_item_css_classes=>'app-Form-fieldContainer--verificationCode'
,p_item_template_options=>'#DEFAULT#'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'Y',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13943139676769738073)
,p_name=>'P9998_RESET_VERIFY_AFTER_X_HOURS'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(13943137590138738044)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13943139687240738064)
,p_name=>'P9998_IS_ACCOUNT_LOCKED_YN'
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(13943137680348738045)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(13943139778972738065)
,p_name=>'P9998_IS_TOKEN_MAXED_YN'
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(13943137680348738045)
,p_display_as=>'NATIVE_HIDDEN'
,p_protection_level=>'I'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(15520062234411346)
,p_computation_sequence=>10
,p_computation_item=>'P9998_RESET_VERIFY_AFTER_X_HOURS'
,p_computation_point=>'BEFORE_BOX_BODY'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'eba_ema_util.get_setting(''reset_verify_after_x_hours'')'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(15518954911411346)
,p_computation_sequence=>10
,p_computation_item=>'P9998_CODE'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'STATIC_ASSIGNMENT'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(15519254978411346)
,p_computation_sequence=>20
,p_computation_item=>'P9998_IS_TOKEN_MAXED_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'eba_ema_util.is_token_maxed_yn (p_username => :P9998_USERNAME)'
);
wwv_flow_imp_page.create_page_computation(
 p_id=>wwv_flow_imp.id(15519681687411346)
,p_computation_sequence=>30
,p_computation_item=>'P9998_IS_ACCOUNT_LOCKED_YN'
,p_computation_point=>'BEFORE_HEADER'
,p_computation_type=>'EXPRESSION'
,p_computation_language=>'PLSQL'
,p_computation=>'eba_ema_util.is_account_locked_yn (p_username => :P9998_USERNAME)'
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(15524079232411350)
,p_name=>'Only Allow Numbers'
,p_event_sequence=>10
,p_triggering_element_type=>'ITEM'
,p_triggering_element=>'P9998_CODE'
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'keypress'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(15524559959411351)
,p_event_id=>wwv_flow_imp.id(15524079232411350)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_JAVASCRIPT_CODE'
,p_attribute_01=>wwv_flow_string.join(wwv_flow_t_varchar2(
'if (this.browserEvent.key.length === 1 && /\D/.test(this.browserEvent.key)) {',
'    this.browserEvent.preventDefault();',
'}'))
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15523685269411349)
,p_process_sequence=>10
,p_process_point=>'AFTER_HEADER'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'redirect to login when token maxed'
,p_process_sql_clob=>'apex_util.redirect_url(apex_util.prepare_url(''f?p=''||:APP_ID||'':login:''||:APP_SESSION||'':NEWCODE:::P9999_USERNAME:''||:P9998_USERNAME)); '
,p_process_clob_language=>'PLSQL'
,p_process_when=>wwv_flow_string.join(wwv_flow_t_varchar2(
':P9998_IS_ACCOUNT_LOCKED_YN = ''N'' and',
':P9998_IS_TOKEN_MAXED_YN = ''Y'''))
,p_process_when_type=>'EXPRESSION'
,p_process_when2=>'SQL'
,p_internal_uid=>15523685269411349
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15520328649411346)
,p_process_sequence=>20
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'Set Username Cookie'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'SEND_LOGIN_USERNAME_COOKIE'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15520328649411346
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15520839539411347)
,p_page_process_id=>wwv_flow_imp.id(15520328649411346)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>1
,p_value_type=>'EXPRESSION'
,p_value_language=>'PLSQL'
,p_value=>':P9998_USERNAME'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(15521210899411348)
,p_process_sequence=>40
,p_process_point=>'AFTER_SUBMIT'
,p_process_type=>'NATIVE_INVOKE_API'
,p_process_name=>'login'
,p_attribute_01=>'PLSQL_PACKAGE'
,p_attribute_03=>'APEX_AUTHENTICATION'
,p_attribute_04=>'LOGIN'
,p_error_display_location=>'INLINE_IN_NOTIFICATION'
,p_internal_uid=>15521210899411348
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15521720225411348)
,p_page_process_id=>wwv_flow_imp.id(15521210899411348)
,p_page_id=>9998
,p_name=>'p_username'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>10
,p_value_type=>'ITEM'
,p_value=>'P9998_USERNAME'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15522207438411348)
,p_page_process_id=>wwv_flow_imp.id(15521210899411348)
,p_page_id=>9998
,p_name=>'p_password'
,p_direction=>'IN'
,p_data_type=>'VARCHAR2'
,p_has_default=>false
,p_display_sequence=>20
,p_value_type=>'ITEM'
,p_value=>'P9998_CODE'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15522772484411348)
,p_page_process_id=>wwv_flow_imp.id(15521210899411348)
,p_page_id=>9998
,p_name=>'p_uppercase_username'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>30
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp_shared.create_invokeapi_comp_param(
 p_id=>wwv_flow_imp.id(15523268507411349)
,p_page_process_id=>wwv_flow_imp.id(15521210899411348)
,p_page_id=>9998
,p_name=>'p_set_persistent_auth'
,p_direction=>'IN'
,p_data_type=>'BOOLEAN'
,p_has_default=>true
,p_display_sequence=>40
,p_value_type=>'API_DEFAULT'
);
wwv_flow_imp.component_end;
end;
/
