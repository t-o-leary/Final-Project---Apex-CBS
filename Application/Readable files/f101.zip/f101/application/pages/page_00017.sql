prompt --application/pages/page_00017
begin
--   Manifest
--     PAGE: 00017
--   Manifest End
wwv_flow_imp.component_begin (
 p_version_yyyy_mm_dd=>'2024.11.30'
,p_release=>'24.2.11'
,p_default_workspace_id=>8287118141200223
,p_default_application_id=>111
,p_default_id_offset=>19426389224188959
,p_default_owner=>'NCIPROJECT'
);
wwv_flow_imp_page.create_page(
 p_id=>17
,p_name=>'add-calendar'
,p_alias=>'ADD-CALENDAR'
,p_page_mode=>'MODAL'
,p_step_title=>'Add Calendar'
,p_autocomplete_on_off=>'OFF'
,p_html_page_header=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<script async defer src="https://apis.google.com/js/api.js" onload="gapiLoaded()"></script>',
'<script async defer src="https://accounts.google.com/gsi/client" onload="gisLoaded()"></script>'))
,p_javascript_code=>wwv_flow_string.join(wwv_flow_t_varchar2(
'/* =============================================================================================================',
unistr('  Author       : Tim O\2019Leary'),
'  Student ID   : 23287021',
'  Version      : 1.0',
'  Program      : Higher Diploma in Science in Computing',
'  Module       : Project (HDSDEV_JAN25)',
'  Lecturer     : Lisa Murphy',
'',
'  Description  : Integrates Google Calendar into an Oracle APEX application.',
'                 Implements client-side OAuth2 authorization using Google Identity. ',
'                 Uses substitution strings for credentials and passing JSON.',
'',
'  Source       : Starter code adapted from https://developers.google.com/workspace/calendar/api/quickstart/js',
'                 ',
'============================================================================================================= */',
'',
'',
'/* exported gapiLoaded */',
'/* exported gisLoaded */',
'/* exported handleAuthClick */',
'/* exported handleSignoutClick */',
'',
'// Use APEX substitution strings for credentials',
'const CLIENT_ID = ''&APP_CLIENT_ID.''; // OAuth Client ID (web application)',
'const API_KEY = ''&APP_API_KEY.'';     // API key',
'',
'// Use write scope to allow creating events',
'const DISCOVERY_DOC = ''https://www.googleapis.com/discovery/v1/apis/calendar/v3/rest'';',
'const SCOPES = ''https://www.googleapis.com/auth/calendar.events'';',
'',
'// Token client and init flags',
'let tokenClient;',
'let gapiInited = false;',
'let gisInited = false;',
'',
'apex.jQuery(function($) {',
'  // hide buttons until libraries are ready',
'  $(''#authorize_button'').css(''visibility'', ''hidden'');',
'  $(''#signout_button'').css(''visibility'', ''hidden'');',
'  $(''#create_event_button'').css(''visibility'', ''hidden'');',
'',
'  // wire up click handlers for the buttons',
'  $(''#authorize_button'').on(''click'', handleAuthClick);',
'  $(''#signout_button'').on(''click'', handleSignoutClick);',
'  $(''#create_event_button'').on(''click'', createAppointment);',
'});',
'',
'/**',
' * gapi loaded callback',
' * Loads the gapi client library and initializes it',
' */',
'function gapiLoaded() {',
'  gapi.load(''client'', initializeGapiClient);',
'}',
'',
'/**',
' * Initialize gapi client',
' * Sets up the discovery doc and API key',
' */',
'async function initializeGapiClient() {',
'  try {',
'    await gapi.client.init({',
'      apiKey: API_KEY,',
'      discoveryDocs: [DISCOVERY_DOC],',
'    });',
'    // mark gapi as initialized and enable buttons if GIS is ready',
'    gapiInited = true;',
'    maybeEnableButtons();',
'  } catch (err) {',
'    // show initialization error in the content area',
'    apex.jQuery(''#content'').text(''gapi init error: '' + err.message);',
'  }',
'}',
'',
'/**',
' * GIS loaded callback',
' * Initializes the Google Identity Services token client',
' */',
'function gisLoaded() {',
'  tokenClient = google.accounts.oauth2.initTokenClient({',
'    client_id: CLIENT_ID,',
'    scope: SCOPES,',
'    callback: '''', // callback assigned dynamically in handleAuthClick',
'  });',
'  // mark GIS as initialized and enable buttons if gapi is ready',
'  gisInited = true;',
'  maybeEnableButtons();',
'}',
'',
'/**',
' * Show authorize button when both libraries are ready',
' */',
'function maybeEnableButtons() {',
'  if (gapiInited && gisInited) {',
'    apex.jQuery(''#authorize_button'').css(''visibility'', ''visible'');',
'  }',
'}',
'',
'/**',
' * Start authorization flow',
' * Requests an access token and updates UI on success',
' */',
'function handleAuthClick() {',
'  // set the token client callback to handle the response',
'  tokenClient.callback = async (resp) => {',
'    if (resp.error !== undefined) {',
'      // display auth error',
'      apex.jQuery(''#content'').text(''Auth error: '' + JSON.stringify(resp));',
'      return;',
'    }',
'    // token acquired: show sign out and create buttons',
'    apex.jQuery(''#signout_button'').css(''visibility'', ''visible'');',
'    apex.jQuery(''#create_event_button'').css(''visibility'', ''visible'');',
'',
'    // add APEX button classes for styling',
'    apex.jQuery(''#authorize_button'').addClass(',
'      ''t-Button t-Button--icon t-Button--primary t-Button--iconLeft t-Button--hoverIconPush''',
'    );',
'',
'    // update authorize button HTML to include icon and label',
'    apex.jQuery(''#authorize_button'').html(',
'      ''<span class="t-Icon t-Icon--left fa fa-refresh" aria-hidden="true"></span> Refresh''',
'    );',
'',
'    // inform the user',
'    apex.jQuery(''#content'').text(''Authorized. You can create an appointment.'');',
'  };',
'',
'  // If no token exists, prompt consent to ensure new scopes are granted',
'  if (gapi.client.getToken() === null) {',
'    tokenClient.requestAccessToken({ prompt: ''consent'' });',
'  } else {',
'    // request token silently for existing session',
'    tokenClient.requestAccessToken({ prompt: '''' });',
'  }',
'}',
'',
'/**',
' * Sign out / revoke token',
' * Revokes the access token and resets UI',
' */',
'function handleSignoutClick() {',
'  const token = gapi.client.getToken();',
'  if (token !== null) {',
'    // revoke token via Google Identity Services',
'    google.accounts.oauth2.revoke(token.access_token);',
'    // clear token from gapi client',
'    gapi.client.setToken('''');',
'    // update UI to show signed out state',
'    apex.jQuery(''#content'').text(''Signed out.'');',
'',
'    // restore original authorize button label (use HTML if icon needed)',
'    apex.jQuery(''#authorize_button'').html(',
'      ''<span class="t-Icon t-Icon--left fa fa-refresh" aria-hidden="true"></span> Authorize''',
'    );',
'',
'    // hide signout and create buttons',
'    apex.jQuery(''#signout_button'').css(''visibility'', ''hidden'');',
'    apex.jQuery(''#create_event_button'').css(''visibility'', ''hidden'');',
'  }',
'}',
'',
'/**',
' * Create an appointment (event.insert)',
' * Uses APEX substitution strings for event details',
' */',
'async function createAppointment() {',
'  // Ensure the user is authorized (token present)',
'  if (!gapi.client.getToken()) {',
'    // request token and ask user to retry after authorizing',
'    tokenClient.requestAccessToken({ prompt: ''consent'' });',
'    apex.jQuery(''#content'').text(''Please authorize first, then click Create Appointment again.'');',
'    return;',
'  }',
'',
'  // Build the event object using APEX substitution strings',
'  const event = {',
'    summary: ''Booking of &P17_NAME. on &P17_START_TS.'',',
'    location: ''&P17_LOCATION.'',',
'    description: ''Created from Oracle APEX using Google Calendar API. &P17_NOTES.'',',
'    start: {',
'      dateTime: ''&P17_CAL_START_TS.'',',
'      timeZone: ''Europe/Dublin''',
'    },',
'    end: {',
'      dateTime: ''&P17_CAL_END_TS.'',',
'      timeZone: ''Europe/Dublin''',
'    },',
'    attendees: [',
'      // can add attendee objects',
'    ],',
'    reminders: {',
'      useDefault: false,',
'      overrides: [',
'        { method: ''email'', minutes: 24 * 60 }, // email reminder 24 hours before',
'        { method: ''popup'', minutes: 10 }       // popup 10 minutes before',
'      ]',
'    }',
'  };',
'',
'  try {',
'    // Insert the event into the user''s primary calendar',
'    const response = await gapi.client.calendar.events.insert({',
'      calendarId: ''primary'',',
'      resource: event',
'    });',
'',
'    const created = response.result;',
'    // show link or event JSON if link not available',
'    apex.jQuery(''#content'').text(''Event created: '' + (created.htmlLink || JSON.stringify(created)));',
'  } catch (err) {',
'    // handle API errors and display a helpful message',
'    const msg = err && err.result && err.result.error',
'      ? JSON.stringify(err.result.error)',
'      : (err.message || JSON.stringify(err));',
'    apex.jQuery(''#content'').text(''Create event error: '' + msg);',
'  }',
'}',
''))
,p_page_template_options=>'#DEFAULT#'
,p_required_role=>wwv_flow_imp.id(34914726140470273)
,p_dialog_resizable=>'Y'
,p_protection_level=>'C'
,p_page_component_map=>'17'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37548948605378505)
,p_plug_name=>unistr('Google Calendar API (APEX) \2014 Authorize and create appointment')
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_location=>null
,p_plug_source=>wwv_flow_string.join(wwv_flow_t_varchar2(
'<div id="gcal_quickstart">',
'  ',
'',
'<!--  <button id="authorize_button" type="button">Authorize</button>',
'  <button id="signout_button" type="button">Sign Out</button>',
'  <button id="create_event_button" type="button">Create Appointment</button>-->',
'',
'  <pre id="content" style="white-space: pre-wrap;"></pre>',
'</div>',
''))
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37549545716378511)
,p_plug_name=>'Container'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>20
,p_location=>null
,p_required_patch=>wwv_flow_imp.id(29299792634077496)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37550160796378517)
,p_plug_name=>'Details'
,p_region_name=>'details'
,p_region_template_options=>'#DEFAULT#:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>40
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(54524752375410388)
,p_plug_name=>'Update Bookings'
,p_parent_plug_id=>wwv_flow_imp.id(37550160796378517)
,p_region_template_options=>'#DEFAULT#'
,p_plug_template=>4501440665235496320
,p_plug_display_sequence=>100
,p_query_type=>'TABLE'
,p_query_table=>'BOOKINGS_V'
,p_include_rowid_column=>false
,p_is_editable=>true
,p_edit_operations=>'i:u:d'
,p_lost_update_check_type=>'VALUES'
,p_plug_source_type=>'NATIVE_FORM'
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37552025807378535)
,p_plug_name=>'Button'
,p_region_template_options=>'#DEFAULT#:t-Region--hideHeader js-addHiddenHeadingRoleDesc:t-Region--scrollBody'
,p_plug_template=>4072358936313175081
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_03'
,p_location=>null
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'expand_shortcuts', 'N',
  'output_as', 'HTML')).to_clob
);
wwv_flow_imp_page.create_page_plug(
 p_id=>wwv_flow_imp.id(37640293836262753)
,p_plug_name=>'Breadcrumb'
,p_region_template_options=>'#DEFAULT#:t-BreadcrumbRegion--useBreadcrumbTitle'
,p_component_template_options=>'#DEFAULT#'
,p_plug_template=>2531463326621247859
,p_plug_display_sequence=>10
,p_plug_display_point=>'REGION_POSITION_01'
,p_location=>null
,p_menu_id=>wwv_flow_imp.id(29300393125077500)
,p_plug_source_type=>'NATIVE_BREADCRUMB'
,p_menu_template_id=>4072363345357175094
,p_required_patch=>wwv_flow_imp.id(29299792634077496)
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37549242862378508)
,p_button_sequence=>10
,p_button_plug_id=>wwv_flow_imp.id(37552025807378535)
,p_button_name=>'Authorize'
,p_button_static_id=>'authorize_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--primary:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Authorize'
,p_button_position=>'CHANGE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-refresh'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37549419224378509)
,p_button_sequence=>20
,p_button_plug_id=>wwv_flow_imp.id(37552025807378535)
,p_button_name=>'Create_Appointment'
,p_button_static_id=>'create_event_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--warning:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Create Appointment'
,p_button_position=>'CHANGE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-calendar-plus-o'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37549525346378510)
,p_button_sequence=>40
,p_button_plug_id=>wwv_flow_imp.id(37552025807378535)
,p_button_name=>'Sign_Out'
,p_button_static_id=>'signout_button'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#:t-Button--iconLeft:t-Button--hoverIconPush'
,p_button_template_id=>2082829544945815391
,p_button_image_alt=>'Sign Out'
,p_button_position=>'CHANGE'
,p_button_execute_validations=>'N'
,p_warn_on_unsaved_changes=>null
,p_icon_css_classes=>'fa-sign-out'
);
wwv_flow_imp_page.create_page_button(
 p_id=>wwv_flow_imp.id(37552332296378538)
,p_button_sequence=>50
,p_button_plug_id=>wwv_flow_imp.id(37552025807378535)
,p_button_name=>'Cancel'
,p_button_action=>'DEFINED_BY_DA'
,p_button_template_options=>'#DEFAULT#'
,p_button_template_id=>4072362960822175091
,p_button_image_alt=>'Cancel'
,p_button_position=>'CLOSE'
,p_warn_on_unsaved_changes=>null
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37549064249378506)
,p_name=>'APP_CLIENT_ID'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37550160796378517)
,p_source=>'27303520117-7p94u3tmir74f9kpcatr33e6iq494bh5.apps.googleusercontent.com'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37549226120378507)
,p_name=>'APP_API_KEY'
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(37550160796378517)
,p_source=>'AIzaSyCVYZtwtJDevU7otnU9ixy2ujBdNH7BqtU'
,p_source_type=>'STATIC'
,p_display_as=>'NATIVE_HIDDEN'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'value_protected', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550392862378519)
,p_name=>'P17_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>10
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_default=>'123'
,p_prompt=>'Id'
,p_source=>'ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_NUMBER_FIELD'
,p_cSize=>30
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'number_alignment', 'left',
  'virtual_keyboard', 'decimal')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550459793378520)
,p_name=>'P17_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>80
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Name'
,p_source=>'NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>63
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550559702378521)
,p_name=>'P17_DEPARTMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>90
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Department'
,p_source=>'DEPARTMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550708174378522)
,p_name=>'P17_RESOURCE_TYPE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>100
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Resource Type'
,p_source=>'RESOURCE_TYPE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550740157378523)
,p_name=>'P17_CSS_CLASS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>110
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Css Class'
,p_source=>'CSS_CLASS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>15
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550873898378524)
,p_name=>'P17_RESOURCE_CODE'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>120
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Resource Code'
,p_source=>'RESOURCE_CODE'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>50
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37550994581378525)
,p_name=>'P17_USERNAME'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>130
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Username'
,p_source=>'USERNAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551085875378526)
,p_name=>'P17_FULL_NAME'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>140
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Full Name'
,p_source=>'FULL_NAME'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551206233378527)
,p_name=>'P17_USER_DEPARTMENT'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>150
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'User Department'
,p_source=>'USER_DEPARTMENT'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551281210378528)
,p_name=>'P17_CHECKEDIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>160
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Checkedin'
,p_source=>'CHECKEDIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551351506378529)
,p_name=>'P17_CHECKIN'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>170
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Checkin'
,p_source=>'CHECKIN'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>22
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551535363378530)
,p_name=>'P17_LOCATION'
,p_source_data_type=>'VARCHAR2'
,p_is_required=>true
,p_item_sequence=>180
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Location'
,p_source=>'LOCATION'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>200
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551586106378531)
,p_name=>'P17_CAL_START_TS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>190
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Cal Start Ts'
,p_source=>'CAL_START_TS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>19
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551691044378532)
,p_name=>'P17_CAL_END_TS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>200
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Cal End Ts'
,p_source=>'CAL_END_TS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>30
,p_cMaxlength=>19
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(37551804285378533)
,p_name=>'P17_NOTES'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>210
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Notes'
,p_source=>'NOTES'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXTAREA'
,p_cSize=>30
,p_cMaxlength=>4000
,p_cHeight=>5
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'auto_height', 'N',
  'character_counter', 'N',
  'resizable', 'Y',
  'trim_spaces', 'BOTH')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54525739879410398)
,p_name=>'P17_RESOURCE_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>20
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Resource Id'
,p_source=>'RESOURCE_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'RESOURCES_ID'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54526185164410400)
,p_name=>'P17_USER_ID'
,p_source_data_type=>'NUMBER'
,p_is_required=>true
,p_item_sequence=>30
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'User Id'
,p_source=>'USER_ID'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_SELECT_LIST'
,p_named_lov=>'CAMPUS_USERS'
,p_lov_display_null=>'YES'
,p_cHeight=>1
,p_read_only_when_type=>'ALWAYS'
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_lov_display_extra=>'YES'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'page_action_on_selection', 'NONE')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54526541271410400)
,p_name=>'P17_START_TS'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_is_required=>true
,p_item_sequence=>40
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Start Ts'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'START_TS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54527378470410401)
,p_name=>'P17_END_TS'
,p_source_data_type=>'TIMESTAMP_TZ'
,p_is_required=>true
,p_item_sequence=>50
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'End Ts'
,p_format_mask=>'DD-MON-YYYY'
,p_source=>'END_TS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_DATE_PICKER_APEX'
,p_cSize=>32
,p_cMaxlength=>255
,p_field_template=>1609122147107268652
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'display_as', 'POPUP',
  'max_date', 'NONE',
  'min_date', 'NONE',
  'multiple_months', 'N',
  'show_time', 'Y',
  'use_defaults', 'Y')).to_clob
);
wwv_flow_imp_page.create_page_item(
 p_id=>wwv_flow_imp.id(54528174905410401)
,p_name=>'P17_STATUS'
,p_source_data_type=>'VARCHAR2'
,p_item_sequence=>60
,p_item_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_item_source_plug_id=>wwv_flow_imp.id(54524752375410388)
,p_prompt=>'Status'
,p_source=>'STATUS'
,p_source_type=>'REGION_SOURCE_COLUMN'
,p_display_as=>'NATIVE_TEXT_FIELD'
,p_cSize=>32
,p_cMaxlength=>20
,p_field_template=>1609121967514267634
,p_item_template_options=>'#DEFAULT#'
,p_is_persistent=>'N'
,p_required_patch=>wwv_flow_imp.id(29299792634077496)
,p_attributes=>wwv_flow_t_plugin_attributes(wwv_flow_t_varchar2(
  'disabled', 'N',
  'submit_when_enter_pressed', 'N',
  'subtype', 'TEXT',
  'trim_spaces', 'BOTH')).to_clob
,p_ai_enabled=>false
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37552071604378536)
,p_name=>'Hide'
,p_event_sequence=>10
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'ready'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37552229388378537)
,p_event_id=>wwv_flow_imp.id(37552071604378536)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'Y'
,p_action=>'NATIVE_HIDE'
,p_affected_elements_type=>'REGION'
,p_affected_region_id=>wwv_flow_imp.id(37550160796378517)
);
wwv_flow_imp_page.create_page_da_event(
 p_id=>wwv_flow_imp.id(37552385197378539)
,p_name=>'Cloese'
,p_event_sequence=>20
,p_triggering_element_type=>'BUTTON'
,p_triggering_button_id=>wwv_flow_imp.id(37552332296378538)
,p_bind_type=>'bind'
,p_execution_type=>'IMMEDIATE'
,p_bind_event_type=>'click'
);
wwv_flow_imp_page.create_page_da_action(
 p_id=>wwv_flow_imp.id(37552525132378540)
,p_event_id=>wwv_flow_imp.id(37552385197378539)
,p_event_result=>'TRUE'
,p_action_sequence=>10
,p_execute_on_page_init=>'N'
,p_action=>'NATIVE_DIALOG_CANCEL'
);
wwv_flow_imp_page.create_page_process(
 p_id=>wwv_flow_imp.id(37551883664378534)
,p_process_sequence=>10
,p_process_point=>'BEFORE_BOX_BODY'
,p_process_type=>'NATIVE_PLSQL'
,p_process_name=>'Insert '
,p_process_sql_clob=>wwv_flow_string.join(wwv_flow_t_varchar2(
'  SELECT',
'    name,',
'    department,',
'    start_ts,',
'    end_ts,',
'    status,',
'    resource_type,',
'    css_class,',
'    resource_id,',
'    resource_code,',
'    user_id,',
'    username,',
'    full_name,',
'    user_department,',
'    checkedin,',
'    checkin,',
'    location,',
'    cal_start_ts,',
'    cal_end_ts,',
'    notes',
'    into',
'        ',
'    :p17_name,',
'    :p17_department,',
'    :p17_start_ts,',
'    :p17_end_ts,',
'    :p17_status,',
'    :p17_resource_type,',
'    :p17_css_class,',
'    :p17_resource_id,',
'    :p17_resource_code,',
'    :p17_user_id,',
'    :p17_username,',
'    :p17_full_name,',
'    :p17_user_department,',
'    :p17_checkedin,',
'    :p17_checkin,',
'    :p17_location,',
'    :p17_cal_start_ts,',
'    :p17_cal_end_ts,',
'    :p17_notes',
'FROM',
'    bookings_v',
'    where id = :p17_id'))
,p_process_clob_language=>'PLSQL'
,p_internal_uid=>18145046367228738
);
wwv_flow_imp.component_end;
end;
/
